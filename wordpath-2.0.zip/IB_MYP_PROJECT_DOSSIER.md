# IB MYP Personal Project Dossier — WordPath 2.0

- **Product Name:** WordPath — Interactive English Learning Platform
- **Slogan:** *Build your English, one focused session at a time.*
- **Global Context:** Scientific and Technical Innovation
- **Cycle:** Learn → Practice → Remember → Track Progress

---

## Criterion A — Planning

### Learning Goal
> “To improve my ability to design and develop interactive web applications using modern web technologies, while researching how learning strategies such as retrieval practice, spaced repetition and contextual learning can be incorporated into a digital platform for B1–B2 English learners.”

### Product Goal
Design and build a responsive, accessible B1–B2 English learning platform featuring:
- **120 curated B1–B2 words** across 10 topics with IPA, definitions, Russian translations, synonyms, collocations, reveal-gated active recall, and a 3-button interval review heuristic (`Again`, `Hard`, `Got it`).
- **12 Grammar Workshops** (48 graded items) with formulas, common error contrasts, and instant rationales.
- **8 Original Reading Passages** (40 comprehension items across MCQ and True/False) with programmatic word counts, Focus Reader mode, clickable inline glossaries, and Web Speech playback.
- **Writing & Speaking Studio** with local draft/transcript storage and optional structured AI evaluation.
- **WordPath AI Mentor** with 5 tutoring modes served via a secure Express/Netlify proxy.
- **Adaptive Learning Path** and **24-Item Informal Placement Check** (with explicit non-CEFR disclaimer).
- **Light & Dark Themes**, onboarding setup, JSON backup export, validated LocalStorage (`wordpath_state_v2` + `wordpath_state_v1` migration), and separated IB documentation.

### Research Question
> “How can retrieval practice, spaced repetition and contextual learning be combined in a web-based platform to support English language learning for B1–B2 students?”

### Verified APA 7 Bibliography
1. Cepeda, N. J., Pashler, H., Vul, E., Wixted, J. T., & Rohrer, D. (2006). Distributed practice in verbal recall tasks: A review and quantitative synthesis. *Psychological Bulletin, 132*(3), 354–380. https://doi.org/10.1037/0033-2909.132.3.354
2. Council of Europe. (2020). *Common European Framework of Reference for Languages: Learning, teaching, assessment — Companion volume*. Council of Europe Publishing. https://www.coe.int/en/web/common-european-framework-reference-languages/cefr-companion-volume
3. Nation, I. S. P. (2022). *Learning vocabulary in another language* (3rd ed.). Cambridge University Press. https://www.cambridge.org/core/books/learning-vocabulary-in-another-language/669D434B8FA228DBCE9FD3E469147DA8
4. Nielsen, J. (2024). *10 usability heuristics for user interface design*. Nielsen Norman Group. https://www.nngroup.com/articles/ten-usability-heuristics/
5. Roediger, H. L., III, & Karpicke, J. D. (2006). Test-enhanced learning: Taking memory tests improves long-term retention. *Psychological Science, 17*(3), 249–255. https://doi.org/10.1111/j.1467-9280.2006.01693.x
6. World Wide Web Consortium. (2023). *Web Content Accessibility Guidelines (WCAG) 2.2*. W3C. https://www.w3.org/TR/WCAG22/

---

## Criterion B & C — Engineering Integrity & Honest Evaluation Boundaries

- **Dynamic Content Synchronization:** Vocabulary (120), Grammar (12 / 48 Qs), Reading (8 passages / 40 Qs), and Placement (24 Qs) counts in `ibProjectData.ts` are computed directly from dataset arrays.
- **Privacy & Secret Isolation:** Server-side `GEMINI_API_KEY` stays strictly in Node/Netlify environment variables. Private IB notes (`ibReflections`) are excluded from all AI payloads and preserved during `Reset Learning Progress`.
- **Academic Honesty:** Personal reflection prompts remain `[Editable]` placeholders in initial state until authored by the student. Live classmate/teacher pilot testing (`Tested by a real user`) and browser visual screenshots remain student-collected evidence items.

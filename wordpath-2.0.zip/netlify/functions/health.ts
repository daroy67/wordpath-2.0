import {
  AIServiceError,
  getConfiguredModelName,
  isAIConfigured
} from '../../server/aiMentorService.ts';

export async function handler() {
  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ok: true,
      aiConfigured: isAIConfigured(),
      model: getConfiguredModelName()
    })
  };
}

export { AIServiceError };

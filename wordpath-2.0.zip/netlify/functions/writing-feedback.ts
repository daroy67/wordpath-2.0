import {
  AIServiceError,
  activeAIProvider,
  validateWritingFeedbackRequest
} from '../../server/aiMentorService.ts';

interface NetlifyEvent {
  httpMethod: string;
  body: string | null;
}

export async function handler(event: NetlifyEvent) {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ errorCode: 'METHOD_NOT_ALLOWED', message: 'Use POST.' })
    };
  }

  try {
    const parsedBody: unknown = event.body ? JSON.parse(event.body) : {};
    const validated = validateWritingFeedbackRequest(parsedBody);
    const result = await activeAIProvider.generateWritingFeedback(validated);
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(result)
    };
  } catch (err) {
    if (err instanceof AIServiceError) {
      return {
        statusCode: err.statusCode,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ errorCode: err.errorCode, message: err.message })
      };
    }
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        errorCode: 'INTERNAL_ERROR',
        message: 'Unexpected server error while generating feedback.'
      })
    };
  }
}
